//
//  ViewController.swift
//  Test
//
//  Created by Hoa Hang on 4/21/17.
//  Copyright © 2017 Hoa Hang. All rights reserved.
//

import UIKit
//import Parse

class ViewController: UIViewController,UITableViewDelegate {
    
    @IBOutlet weak var lblReenterPwd: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblNewPassword: UILabel!
    @IBOutlet weak var lblCurrentPassword: UILabel!
    @IBOutlet weak var lblUsername: UILabel!
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtReEnterPassword: UITextField!
    @IBOutlet weak var txtCurrentPassword: UITextField!
    @IBOutlet weak var txtNewPassword: UITextField!
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var btnLogOut: UIButton!
    //@IBOutlet weak var btnCancel: UIButton!
    var email: String? ;
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //txtUserName.text = "hqhoak992003@gmail.com";
        email = "hqhoak992003@gmail.com" //UserDefaults.standard.string(forKey: "username")
        UserDefaults.standard.set(email, forKey: "username")
        
        //txtUserName.isEnabled = false
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func submitChangePassword(_ sender: UIButton)
    {
        let currPwd = txtCurrentPassword.text
        let newPwd = txtNewPassword.text
        let reEnterPwd = txtReEnterPassword.text
        if(email == nil){
            displayAlertMessage(userMessage:"Missing username!!!")
            return
        }
        if((currPwd?.isEmpty)! || (newPwd?.isEmpty)! || (reEnterPwd?.isEmpty)!){
            // display msg to notice old and new password are the same
            displayAlertMessage(userMessage:"All fields are not empty!!!")
            return
        }
        if((newPwd?.characters.count)! < 8){
            // display msg to notice the password length
            displayAlertMessage(userMessage:"Password should have at least eight characters!!!")
            return
        }
        if(currPwd == newPwd){
            // display msg to notice the same password
            displayAlertMessage(userMessage:"New Password is not the same current password!!!")
            return
        }
        if(newPwd != reEnterPwd){
            // display msg to notice the same password
            displayAlertMessage(userMessage:"New password does not match!!!")
            return
        }
        // get data and store
        let ipAddress = "http://130.65.159.80/user_setting.php"
        let url = URL(string: ipAddress)
        var request = URLRequest(url: url!)
        request.httpMethod = "POST"
        
        let postString = "email=\(String(describing:email!))&newPassword=\(String(describing:newPwd!))&currPassword=\(String(describing:currPwd!))"
        
        request.httpBody = postString.data(using: String.Encoding.utf8)
        
        URLSession.shared.dataTask(with: request, completionHandler:
            {
                (data, response, error) -> Void in
                if(error != nil)
                {
                    print("error=\(String(describing: error))\n")
                    return
                }
                do
                {
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    if let parseJSON = json
                    {
                        let resultValue: String = parseJSON["status"] as! String
                        print("result: \(resultValue)\n")
                        let messageToDisplay = parseJSON["message"] as! String!
                        DispatchQueue.main.async
                        {
                                self.displayAlertMessage(userMessage: messageToDisplay!);
                        }

                        
                        /*if(resultValue == "success")
                        {
                            UserDefaults.standard.set(parseJSON["user"], forKey: "username")
                            UserDefaults.standard.set(parseJSON["usertype"], forKey: "type")
                            UserDefaults.standard.synchronize()
                            self.dismiss(animated: true, completion: nil)
                            let messageToDisplay = parseJSON["message"] as! String!
                            DispatchQueue.main.async
                            {
                                self.displayAlertMessage(userMessage: messageToDisplay!);
                            }
                        }
                        else
                        {
                            let messageToDisplay = parseJSON["message"] as! String!
                            DispatchQueue.main.async
                                {
                                    self.displayAlertMessage(userMessage:messageToDisplay!)
                            }
                        }*/
                    }
                }
                catch let error as Error?
                {
                    print("Found an error - \(String(describing: error))")
                }
                
        }).resume()
    }

    
    @IBAction func logOut(_ sender: UIButton) {
        if(UserDefaults.standard.string(forKey: "username") != nil){
            UserDefaults.standard.removeObject(forKey: "username")
            UserDefaults.standard.synchronize()
            //PFUser.
            self.displayAlertMessage(userMessage: "Logout is successful!!!")
        }
        // Nagivate to the homepage
        let mainStoryBoard:UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let homePage:ViewController = mainStoryBoard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        let homePageNav = UINavigationController(rootViewController: homePage);
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        appDelegate?.window?.rootViewController = homePageNav
        appDelegate?.window?.makeKeyAndVisible()
        
        //let myViewController:ViewController = self.storyboard!.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        //let appDelegate = UIApplication.shared.delegate as? AppDelegate
        //appDelegate?.window?.rootViewController = myViewController
        //appDelegate?.window?.makeKeyAndVisible()
        
        //var mainPage:MainPageViewController = mainStoryBoard.instantiateViewController(withIdentifier: "MainPageViewController") as! MainPageViewController
        
    }
    /*@IBAction func cancelChangePassword(_ sender: UIButton) {
    }*/
    func displayAlertMessage(userMessage:String){
        let myAlert = UIAlertController(title:"Alert", message:userMessage, preferredStyle:UIAlertControllerStyle.alert)
        let okAction = UIAlertAction(title:"OK", style: UIAlertActionStyle.default, handler: nil)
        myAlert.addAction(okAction)
        self.present(myAlert, animated: true, completion:nil)
        
    }
}

